#version 330 compatibility

/*
Physics Mod Ocean Physics 2.0 support for LIGHT Shaders (Pro v185+).

The wave library below is taken from the official reference implementation:
https://github.com/haubna/PhysicsMod (oceans.glsl)
The wave shape has to stay byte-identical because it is also evaluated on
the CPU side to offset entities.

The surface shading is ported from LIGHT Shaders' gbuffers_water so the
simulated ocean matches the pack's vanilla water:
  - colortex5: lit water color (alpha 0.4)
  - colortex2: encoded wave normal (decoded length 0.95 = water, so the
    composite pass applies refraction, caustics and reflections)
  - colortex6: raw water albedo
*/

const int PHYSICS_ITERATIONS_OFFSET = 13;
const float PHYSICS_DRAG_MULT = 0.048;
const float PHYSICS_XZ_SCALE = 0.035;
const float PHYSICS_TIME_MULTIPLICATOR = 0.45;
const float PHYSICS_W_DETAIL = 0.75;
const float PHYSICS_FREQUENCY = 6.0;
const float PHYSICS_SPEED = 2.0;
const float PHYSICS_WEIGHT = 0.8;
const float PHYSICS_FREQUENCY_MULT = 1.18;
const float PHYSICS_SPEED_MULT = 1.07;
const float PHYSICS_ITER_INC = 12.0;
const float PHYSICS_NORMAL_STRENGTH = 0.6;
const float PHYSICS_RIPPLE_VERTEX_DISPLACEMENT = 0.01;
const float PHYSICS_RIPPLE_NORMAL_STRENGTH = 0.042;
const float PHYSICS_RIPPLE_NORMAL_MAX_BLEND = 0.32;
const float PHYSICS_RIPPLE_NORMAL_SAMPLE_WORLD_DISTANCE = 0.25;
const float PHYSICS_RIPPLE_EDGE_FADE = 0.035;

layout(std140) uniform PhysicsOcean {
    float physics_gameTime;
    float physics_globalTime;
    int physics_iterationsNormal;
    float physics_oceanHeight;
    float physics_oceanWaveHorizontalScale;
    float physics_rippleRange;
    float physics_foamAmount;
    float physics_foamOpacity;
};

layout(std140) uniform PhysicsOceanChunk {
    float physics_modelOffsetX;
    float physics_modelOffsetY;
    float physics_modelOffsetZ;
    float physics_waveOffsetX;
    float physics_waveOffsetZ;
};

// texture containing the ripples (basic bump map)
uniform sampler2D physics_ripples;
// foam noise
uniform sampler3D physics_foam;
// just the generic minecraft lightmap
uniform sampler2D physics_lightmap;

vec2 physics_rippleUv(const in vec2 position) {
    vec2 eyePosition = position + vec2(physics_modelOffsetX, physics_modelOffsetZ);
    return (eyePosition + vec2(physics_rippleRange)) / (physics_rippleRange * 2.0);
}

float physics_rippleUvMask(const in vec2 uv) {
    if (uv.x < 0.0 || uv.y < 0.0 || uv.x > 1.0 || uv.y > 1.0) {
        return 0.0;
    }

    float edge = min(min(uv.x, uv.y), min(1.0 - uv.x, 1.0 - uv.y));
    return smoothstep(0.0, PHYSICS_RIPPLE_EDGE_FADE, edge);
}

float physics_rippleSampleRaw(const in vec2 position) {
    vec2 uv = physics_rippleUv(position);
    return texture(physics_ripples, uv).r * physics_rippleUvMask(uv);
}

float physics_rippleVertexHeight(const in vec2 position) {
    return physics_rippleSampleRaw(position) * PHYSICS_RIPPLE_VERTEX_DISPLACEMENT;
}

vec3 physics_waveNormal(const in vec2 position, const in vec2 direction, const in float factor, const in float time) {
    float oceanHeightFactor = physics_oceanHeight / 13.0;
    float totalFactor = oceanHeightFactor * factor;
    vec3 waveNormal = normalize(vec3(direction.x * totalFactor, PHYSICS_NORMAL_STRENGTH, direction.y * totalFactor));

    float rippleTexelSize = 1.0 / textureSize(physics_ripples, 0).x;
    float texelWorldSize = max((physics_rippleRange * 2.0) * rippleTexelSize, 0.001);
    float normalSampleDistance = min(texelWorldSize, PHYSICS_RIPPLE_NORMAL_SAMPLE_WORLD_DISTANCE);

    float center = physics_rippleSampleRaw(position);
    float left = physics_rippleSampleRaw(position - vec2(normalSampleDistance, 0.0));
    float right = physics_rippleSampleRaw(position + vec2(normalSampleDistance, 0.0));
    float top = physics_rippleSampleRaw(position - vec2(0.0, normalSampleDistance));
    float bottom = physics_rippleSampleRaw(position + vec2(0.0, normalSampleDistance));
    float totalEffect = abs(center) + abs(left) + abs(right) + abs(top) + abs(bottom);

    float rippleSlopeX = ((left - right) / (normalSampleDistance * 2.0)) * PHYSICS_RIPPLE_NORMAL_STRENGTH;
    float rippleSlopeZ = ((top - bottom) / (normalSampleDistance * 2.0)) * PHYSICS_RIPPLE_NORMAL_STRENGTH;
    float rippleBlend = smoothstep(0.006, 0.10, totalEffect) * PHYSICS_RIPPLE_NORMAL_MAX_BLEND;

    vec2 baseSlope = waveNormal.xz / max(waveNormal.y, 0.001);
    vec2 combinedSlope = baseSlope + vec2(rippleSlopeX, rippleSlopeZ) * rippleBlend;
    return normalize(vec3(combinedSlope.x, 1.0, combinedSlope.y));
}

struct WavePixelData {
    vec2 direction;
    vec2 worldPos;
    vec3 normal;
    float foam;
    float height;
};

WavePixelData physics_wavePixel(
    const in vec2 position,
    const in float factor,
    const in float iterations,
    const in float time
) {
    float adjustedFactor = clamp(factor * 2.0, 0.1, 1.0);
    vec2 wavePos = (position.xy - vec2(physics_waveOffsetX, physics_waveOffsetZ)) * PHYSICS_XZ_SCALE * physics_oceanWaveHorizontalScale;
    float iter = 0.0;
    float frequency = PHYSICS_FREQUENCY;
    float speed = PHYSICS_SPEED;
    float weight = 1.0;
    float height = 0.0;
    float waveSum = 0.0;
    float modifiedTime = time * PHYSICS_TIME_MULTIPLICATOR;
    vec2 dx = vec2(0.0);

    for (int i = 0; i < iterations; i++) {
        vec2 direction = vec2(sin(iter), cos(iter));
        float x = dot(direction, wavePos) * frequency + modifiedTime * speed;
        float wave = exp(sin(x) - 1.0);
        float result = wave * cos(x);
        vec2 force = result * weight * direction;

        dx += force / pow(weight, PHYSICS_W_DETAIL);
        wavePos -= force * PHYSICS_DRAG_MULT * adjustedFactor;
        height += wave * weight;
        iter += PHYSICS_ITER_INC;
        waveSum += weight;
        weight *= PHYSICS_WEIGHT;
        frequency *= PHYSICS_FREQUENCY_MULT;
        speed *= PHYSICS_SPEED_MULT;
    }

    WavePixelData data;
    data.direction = -vec2(dx / pow(waveSum, 1.0 - PHYSICS_W_DETAIL));
    data.worldPos = wavePos / physics_oceanWaveHorizontalScale / PHYSICS_XZ_SCALE;
    float baseHeight = height / waveSum * physics_oceanHeight * factor - physics_oceanHeight * factor * 0.5;
    float rippleHeight = physics_rippleVertexHeight(position);
    data.height = baseHeight + rippleHeight;

    data.normal = physics_waveNormal(position, data.direction, max(0.1, factor), time);

    float waveAmplitude = data.height * pow(max(data.normal.y, 0.0), 4.0);
    float rippleFoam = smoothstep(0.10, 0.38, abs(rippleHeight));
    vec2 waterUV = mix(position - vec2(physics_waveOffsetX, physics_waveOffsetZ), data.worldPos, clamp(factor * 2.0, 0.2, 1.0));

    vec2 s1 = textureLod(physics_foam, vec3(waterUV * 0.26, physics_globalTime / 360.0), 0).rg;
    vec2 s2 = textureLod(physics_foam, vec3(waterUV * 0.02, physics_globalTime / 360.0 + 0.5), 0).rg;
    vec2 s3 = textureLod(physics_foam, vec3(waterUV * 0.1, physics_globalTime / 360.0 + 1.0), 0).rg;

    float waterSurfaceNoise = s1.r * s2.r * s3.r * 2.8 * physics_foamAmount;
    waveAmplitude = clamp(waveAmplitude * 1.2, 0.0, 1.0);
    waterSurfaceNoise = (1.0 - waveAmplitude) * waterSurfaceNoise + waveAmplitude * physics_foamAmount;

    float worleyNoise = 0.2 + 0.8 * s1.g * (1.0 - s2.g);
    float waterFoamMinSmooth = 0.45;
    float waterFoamMaxSmooth = 2.0;
    waterSurfaceNoise = smoothstep(waterFoamMinSmooth, 1.0, waterSurfaceNoise) * worleyNoise;

    data.foam = clamp(waterFoamMaxSmooth * waterSurfaceNoise * physics_foamOpacity, 0.0, 1.0);

    return data;
}

// FRAGMENT STAGE
in vec3 physics_localPosition;
in float physics_localWaviness;

uniform vec3 sunPosition;
uniform vec3 upPosition;
uniform int worldTime;
uniform float rainStrength;

// Time of day sunlight colors, same table as gbuffers_water
const vec3 ToD[7] = vec3[7](vec3(0.58597, 0.16, 0.025),
                            vec3(0.58597, 0.4, 0.2),
                            vec3(0.58597, 0.52344, 0.24680),
                            vec3(0.58597, 0.55422, 0.34),
                            vec3(0.58597, 0.57954, 0.38),
                            vec3(0.58597, 0.58, 0.40),
                            vec3(0.58597, 0.58, 0.40));

const vec3 moonlight = vec3(0.5, 0.9, 1.4) * 0.004;

//////////////////////////////VOID MAIN//////////////////////////////
//////////////////////////////VOID MAIN//////////////////////////////
//////////////////////////////VOID MAIN//////////////////////////////
//////////////////////////////VOID MAIN//////////////////////////////
//////////////////////////////VOID MAIN//////////////////////////////

void main() {
    WavePixelData wave = physics_wavePixel(physics_localPosition.xz, physics_localWaviness, physics_iterationsNormal, physics_gameTime);

    // wave.normal is in world space, convert it to view space
    vec3 normal = normalize(gl_NormalMatrix * wave.normal);

    vec3 sunVec = normalize(sunPosition);
    vec3 upVec = normalize(upPosition);

    vec2 visibility = vec2(dot(sunVec, upVec), dot(-sunVec, upVec));
    visibility = pow(clamp(visibility + 0.15, 0.0, 0.15) / 0.15, vec2(4.0));

    float NdotL = dot(normal, sunVec);
    float NdotU = dot(normal, upVec);

    vec2 trCalc = min(abs(float(worldTime) - vec2(23250.0, 12700.0)), 800.0);
    float tr = max(min(trCalc.x, trCalc.y) / 400.0 - 1.0, 0.0);

    // Time of day sunlight color
    float hour = max(mod(worldTime / 1000.0 + 2.0, 24.0) - 2.0, 0.0);
    float cmpH = max(-abs(floor(hour) - 6.0) + 6.0, 0.0);
    float cmpH1 = max(-abs(floor(hour) - 5.0) + 6.0, 0.0);
    vec3 sunlight = mix(ToD[int(cmpH)], ToD[int(cmpH1)], fract(hour));
    const vec3 rainC = vec3(0.005, 0.007, 0.009);
    sunlight = mix(sunlight, rainC * sunlight, rainStrength);

    // The ocean surface always sees the full sky
    float skyL = 1.0;
    float SkyL2 = skyL * skyL;
    float skyc2 = mix(1.0, SkyL2, skyL);

    vec4 bounced = vec4(NdotL, NdotL, NdotL, NdotU) * vec4(-0.05 * skyL * skyL, 0.32, 0.7, 0.18) + vec4(0.5, 0.66, 0.7, 0.3);
    bounced *= vec4(skyc2, skyc2, visibility.x - tr * visibility.x, 0.8);

    vec3 sun_ambient = bounced.w * (vec3(0.16, 0.5, 1.5) - rainStrength * vec3(0.0, 0.3, 1.27)) + sunlight * (sqrt(bounced.w) * bounced.x * 3. + bounced.z);
    vec3 moon_ambient = (moonlight + moonlight * bounced.y) * (1.0 - rainStrength * 0.5);

    vec3 lightColor = mix(sunlight, moonlight * (1.0 - rainStrength * 0.6), visibility.y) * tr;

    if (worldTime > 12700 && worldTime < 23250) NdotL = -NdotL;

    vec3 ambientNdotL = (sun_ambient * visibility.x + moon_ambient * visibility.y) * SkyL2 * (0.03 + tr * 0.17) * 0.8 + vec3(0.0012, 0.0012, 0.0012) * min(skyL + 6. / 16., 9. / 16.);

    // The ocean is its own light blocker, no shadow map sample here
    vec3 sunlightL = lightColor * 0.9;

    // Same water color the pack uses for vanilla water
    vec3 colorrgb = vec3(0.35, 0.67, 0.72) * 0.4;
    // Blend in the simulated foam
    colorrgb = mix(colorrgb, vec3(0.8), clamp(wave.foam, 0.0, 1.0) * 0.75);

    vec3 fColor = (sunlightL * max(NdotL, 0.0) + ambientNdotL) * colorrgb;
    fColor = pow(fColor, vec3(1.0 / 2.2));

    /* DRAWBUFFERS:526 */
    // Encoded normal uses the water scale (0.5 - 0.025) so the composite
    // pass recognizes the surface as water (decoded length 0.95).
    gl_FragData[0] = vec4(fColor, 0.4);
    gl_FragData[1] = vec4(normal * (0.5 - 0.025) + 0.5, 1.0);
    gl_FragData[2] = vec4(pow(colorrgb, vec3(1.0 / 2.2)), 0.4);
}
